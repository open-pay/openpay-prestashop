<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{openpaycheckoutlending}prestashop>configuration_9f86f95efc1088fc79d4364b0e95c001'] = 'Comienza tu experiencia en Openpay aceptando pagos con checkout lending.';
