## Plugin para PrestaShop - Openpay

=================

## Instalación

1. Comprimir el directorio "openpayprestashop" en formato .zip y subirlo por el manejador de módulos de PrestaShop. Si prefiere la opción vía FTP deberá subir el directorio "openpayprestashop" al directorio "modules" ubicado en el directorio raíz de PrestaShop.

2. En la administración de Prestashop (backoffice) ir a: **Módulos > Módulos** y buscar el nombre del módulo: **openpaycards** y dar click en "Instalar". Una vez instlado recibirá el siguiente mensaje: " Módulo(s) instalado correctamente."

3. Agregar las llaves, ir al panel de administración de Openpay (https://sandbox-dashboard.openpay.mx/login), copiar y pegar las llaves, dentro de las configuraciones del módulo en el panel de administración de PrestaShop (backoffice).

