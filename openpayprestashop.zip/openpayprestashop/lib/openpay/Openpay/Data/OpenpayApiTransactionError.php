<?php

namespace Openpay\Data;

class OpenpayApiTransactionError extends OpenpayApiError
{

}
